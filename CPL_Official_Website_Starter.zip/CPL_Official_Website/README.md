# CPL Official Website — starter kit

A responsive CPL (Chagantivaripalem Premier League) website with a Supabase-powered admin panel.

## What is included
- Public home page, fixtures/results, teams and points table
- Admin sign-in, add/delete teams, publish matches, edit points table
- Responsive desktop/mobile layout
- Supabase database schema

## Important: connect the free backend first
This starter is a front end. The admin panel will not save shared/live data until you connect Supabase.

1. Create a free project at https://supabase.com/ (ask a parent/guardian to help with account setup if needed).
2. In Supabase, open **SQL Editor**, paste all of `schema.sql`, and run it.
3. In **Authentication → Users**, create the administrator account (email and password).
4. In **Project Settings → API**, copy the Project URL and the `anon` / publishable key.
5. Open `config.js` and replace `YOUR_SUPABASE_PROJECT_URL` and `YOUR_SUPABASE_ANON_KEY`.
   - Never use or publish the `service_role` / secret key.
6. Test locally by opening `index.html` with an internet connection. For reliable local testing, use a simple local web server.

## Free hosting
1. Create a GitHub repository and upload all files in this folder.
2. In the repository, open **Settings → Pages**.
3. Choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
4. GitHub Pages will provide a public `github.io` address. You can share it.
5. To update the website, upload changed files to the repository. Keep a backup copy.

## Security note
The supplied SQL policies allow any authenticated account in this Supabase project to manage the league data. Keep admin account creation restricted to trusted officials and do not enable public sign-ups. For a larger production setup, add a dedicated admin-role table and stricter policies before inviting more users.

## Before launch
Replace the sample text/branding if required, add official CPL logo and approved team photos, verify match data, and test the admin login. Free hosting and free backend plans can change their limits and terms; no provider can promise a website will exist forever. Keep periodic backups of the repository and database.
