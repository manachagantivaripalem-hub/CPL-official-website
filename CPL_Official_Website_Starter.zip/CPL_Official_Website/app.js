const $ = s => document.querySelector(s);
const config = window.CPL_CONFIG || {};
let db = null;
if (window.supabase && config.supabaseUrl && !config.supabaseUrl.startsWith("YOUR_") && config.supabaseAnonKey && !config.supabaseAnonKey.startsWith("YOUR_")) db = window.supabase.createClient(config.supabaseUrl, config.supabaseAnonKey);
$("#year").textContent = new Date().getFullYear();
$("#menuToggle").addEventListener("click",()=>$("#nav").classList.toggle("open"));
function esc(v=""){return String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function dateFmt(v){const d=new Date(v);return isNaN(d)?v:d.toLocaleString("en-IN",{day:"numeric",month:"short",year:"numeric",hour:"numeric",minute:"2-digit"});}
async function load(){
 let teams=[],matches=[],points=[];
 if(db){
  const [t,m,p]=await Promise.all([db.from("teams").select("*").order("name"),db.from("matches").select("*").order("match_time"),db.from("points_table").select("*").order("points",{ascending:false})]);
  if(!t.error) teams=t.data||[]; if(!m.error) matches=m.data||[]; if(!p.error) points=p.data||[];
 }
 $("#teamCount").textContent=teams.length; $("#matchCount").textContent=matches.length; $("#playedCount").textContent=matches.filter(x=>x.status==="Completed").length;
 $("#teamsList").innerHTML=teams.length?teams.map((t,i)=>`<article class="team-card"><span class="team-number">${String(i+1).padStart(2,"0")}</span><div><h3>${esc(t.name)}</h3><small>${esc(t.short_name||"CPL TEAM")}</small></div><b>✦</b></article>`).join(""):'<div class="empty">Team announcements coming soon.</div>';
 $("#matchesList").innerHTML=matches.length?matches.map(m=>`<article class="match-card"><div class="match-meta"><span>${esc(m.status||"Upcoming")}</span><time>${esc(dateFmt(m.match_time))}</time></div><div class="versus"><b>${esc(m.team1)}</b><span>VS</span><b>${esc(m.team2)}</b></div><div class="match-foot"><span>📍 ${esc(m.venue||"Chagantivaripalem")}</span><span>${esc(m.result||"Match details soon")}</span></div></article>`).join(""):'<div class="empty">Fixtures will appear here once published by the CPL team.</div>';
 $("#pointsBody").innerHTML=points.length?points.map((p,i)=>`<tr><td>${i+1}</td><td><b>${esc(p.team_name)}</b></td><td>${p.played}</td><td>${p.won}</td><td>${p.lost}</td><td><b>${p.points}</b></td></tr>`).join(""):'<tr><td colspan="6" class="empty">Points table will be updated after matches begin.</td></tr>';
}
load();